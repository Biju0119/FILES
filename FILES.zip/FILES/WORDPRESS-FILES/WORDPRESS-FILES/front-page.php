<?php get_header(); ?>
<?php @include ('home-banner.php');?>
<?php @include ('mid-box.php');?>
<?php @include ('home-box.php');?>
<?php @include ('footer.box.php');?>		
<?php get_footer(); ?>